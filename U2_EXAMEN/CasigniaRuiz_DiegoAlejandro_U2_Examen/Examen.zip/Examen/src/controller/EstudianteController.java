package controller;

import dao.EstudianteDAO;
import model.Estudiante;
import java.util.List;

/**
 * la clase EstudianteController gestiona las operaciones crud
 * Actúa como intermediario entre el Main y el EstudianteDAO.
 */
public class EstudianteController {

    /**
     * Instancia de EstudianteDAO
     */
    private EstudianteDAO dao = new EstudianteDAO();

    /**
     * Crea un nuevo estudiante
     *
     * @param id         ID único del estudiante
     * @param apellidos  Apellidos del estudiante
     * @param nombres    Nombres del estudiante
     * @param edad       Edad del estudiante
     */
    public void crearEstudiante(int id, String apellidos, String nombres, int edad) {
        Estudiante e = new Estudiante(id, apellidos, nombres, edad);
        dao.agregar(e);
    }

    /**
     * Obtiene la lista de todos los estudiantes registrados.
     *
     * @return Lista<Estudiante>
     */
    public List<Estudiante> obtenerTodos() {
        return dao.listar();
    }

    /**
     * Busca un estudiante por su ID.
     *
     * @param id
     * @return Estudiante
     */
    public Estudiante buscarEstudiante(int id) {
        return dao.buscarPorId(id);
    }

    /**
     * Actualiza la información de un estudiante
     *
     * @param id
     * @param apellidos
     * @param nombres
     * @param edad
     * @return boolean
     */
    public boolean actualizarEstudiante(int id, String apellidos, String nombres, int edad) {
        Estudiante actualizado = new Estudiante(id, apellidos, nombres, edad);
        return dao.actualizar(actualizado);
    }

    /**
     * Elimina un estudiante
     *
     * @param id ID del estudiante a eliminar
     * @return boolean si se eliminó o no el estudiante
     */
    public boolean eliminarEstudiante(int id) {
        return dao.eliminar(id);
    }
}
