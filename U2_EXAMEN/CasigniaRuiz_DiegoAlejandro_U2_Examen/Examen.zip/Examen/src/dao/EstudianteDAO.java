package dao;

import java.util.ArrayList;
import java.util.List;
import model.Estudiante;

/**
 * La clase EstudianteDAO actúa como un repositorio para gestionar el objeto Estudiante
 * Proporciona métodos CRUD del Estudiante
 *
 */
public class EstudianteDAO {

    /** Lista en memoria que almacena los estudiantes */
    private List<Estudiante> estudiantes = new ArrayList<>();

    /** Agrega un nuevo estudiante a la lista*/
    public void agregar(Estudiante e) {
        estudiantes.add(e);
    }

    /**
     * Devuelve la lista completa de estudiantes.
     *
     * @return Lista<Estudiante>
     */
    public List<Estudiante> listar() {
        return estudiantes;
    }

    /**
     * Busca un estudiante por su id
     *
     * @param id
     * @return estudiante
     */
    public Estudiante buscarPorId(int id) {
        for (Estudiante e : estudiantes) {
            if (e.getId() == id) {
                return e;
            }
        }
        return null;
    }

    /**
     * Elimina un estudiante con su id
     *
     * @param id ID del estudiante a eliminar
     * @return boolean
     */
    public boolean eliminar(int id) {
        Estudiante e = buscarPorId(id);
        if (e != null) {
            estudiantes.remove(e);
            return true;
        }
        return false;
    }

    /**
     * Actualiza los datos de un estudiante existente
     *
     * @param nuevoEstudiante
     * @return boolean
     */
    public boolean actualizar(Estudiante nuevoEstudiante) {
        for (int i = 0; i < estudiantes.size(); i++) {
            if (estudiantes.get(i).getId() == nuevoEstudiante.getId()) {
                estudiantes.set(i, nuevoEstudiante);
                return true;
            }
        }
        return false;
    }
}
