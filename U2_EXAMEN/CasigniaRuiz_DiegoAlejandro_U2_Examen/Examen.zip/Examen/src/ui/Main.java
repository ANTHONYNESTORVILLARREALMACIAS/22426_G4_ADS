package ui;

import controller.EstudianteController;
import model.Estudiante;
import java.util.Scanner;

/**
 * la clase Main funciona como una capa vista ya que muestra por consola un menu que permite
 * al usuario realizar las operaciones crud de estudiantes
 */

public class Main {
    public static void main(String[] args) {

        /** Instancia del EstudianteController */
        EstudianteController controller = new EstudianteController();

        Scanner sc = new Scanner(System.in);
        int opcion;

        // bucle para la persistencia del menu
        do {
            //Se muestra el menu por consola
            System.out.println("\n--- MENU CRUD ESTUDIANTES ---");
            System.out.println("1. Agregar estudiante");
            System.out.println("2. Mostrar todos los estudiantes");
            System.out.println("3. Buscar estudiante por ID");
            System.out.println("4. Actualizar estudiante");
            System.out.println("5. Eliminar estudiante");
            System.out.println("0. Salir");
            System.out.print("Seleccione una opción: ");
            opcion = sc.nextInt();
            sc.nextLine();

            switch (opcion) {
                case 1:
                    System.out.print("ID: ");
                    int id = sc.nextInt();
                    sc.nextLine();
                    System.out.print("Apellidos: ");
                    String apellidos = sc.nextLine();
                    System.out.print("Nombres: ");
                    String nombres = sc.nextLine();
                    System.out.print("Edad: ");
                    int edad = sc.nextInt();
                    controller.crearEstudiante(id, apellidos, nombres, edad);
                    System.out.println("Estudiante agregado correctamente.");
                    break;
                case 2:
                    System.out.println("\nLista de estudiantes:");
                    for (Estudiante e : controller.obtenerTodos()) {
                        System.out.println(e.getId() + " - " + e.getApellidos() + " " + e.getNombres() + " - Edad: " + e.getEdad());
                    }
                    break;
                case 3:
                    System.out.print("Ingrese ID del estudiante: ");
                    int idBuscar = sc.nextInt();
                    Estudiante e = controller.buscarEstudiante(idBuscar);
                    if (e != null) {
                        System.out.println("Encontrado: " + e.getId() + " - " + e.getApellidos() + " " + e.getNombres() + " - Edad: " + e.getEdad());
                    } else {
                        System.out.println("Estudiante no encontrado.");
                    }
                    break;
                case 4:
                    System.out.print("ID del estudiante a actualizar: ");
                    int idActualizar = sc.nextInt();
                    sc.nextLine();
                    System.out.print("Nuevos apellidos: ");
                    String nuevosApellidos = sc.nextLine();
                    System.out.print("Nuevos nombres: ");
                    String nuevosNombres = sc.nextLine();
                    System.out.print("Nueva edad: ");
                    int nuevaEdad = sc.nextInt();
                    boolean actualizado = controller.actualizarEstudiante(idActualizar, nuevosApellidos, nuevosNombres, nuevaEdad);
                    System.out.println(actualizado ? "Estudiante actualizado." : "No se encontró el estudiante.");
                    break;
                case 5:
                    System.out.print("ID del estudiante a eliminar: ");
                    int idEliminar = sc.nextInt();
                    boolean eliminado = controller.eliminarEstudiante(idEliminar);
                    System.out.println(eliminado ? "Estudiante eliminado." : "No se encontró el estudiante.");
                    break;
                case 0:
                    System.out.println("Saliendo del sistema...");
                    break;
                default:
                    System.out.println("Opción inválida.");
            }
        } while (opcion != 0);

        sc.close();
    }
}

