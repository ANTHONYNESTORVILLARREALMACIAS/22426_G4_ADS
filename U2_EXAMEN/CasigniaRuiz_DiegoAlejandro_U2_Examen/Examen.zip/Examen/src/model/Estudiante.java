package model;

/**
 * La clase Estudiante representa a un estudiante con atributos básicos como
 * ID, apellidos, nombres y edad.
 * Proporciona métodos para acceder y modificar estos atributos.
 */
public class Estudiante {
    private int id;
    private String apellidos;
    private String nombres;
    private int edad;

    /**
     * Constructor:
     * @param id        id unico del estudiante
     * @param apellidos apellidos del estudiante
     * @param nombres   nombres del estudiante
     * @param edad      edad del estudiante
     */
    public Estudiante(int id, String apellidos, String nombres, int edad) {
        this.id = id;
        this.apellidos = apellidos;
        this.nombres = nombres;
        this.edad = edad;
    }

    /**
     * @return id
     */
    public int getId() {
        return id;
    }

    /**
     * Establece el ID del estudiante.
     * @param id
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * Obtiene los apellidos del estudiante.
     * @return apellidos
     */
    public String getApellidos() {
        return apellidos;
    }

    /**
     * Establece los apellidos del estudiante.
     * @param apellidos
     */
    public void setApellidos(String apellidos) {
        this.apellidos = apellidos;
    }

    /**
     * Obtiene los nombres del estudiante.
     * @return Nombres del estudiante
     */
    public String getNombres() {
        return nombres;
    }

    /**
     * Establece los nombres del estudiante.
     * @param nombres
     */
    public void setNombres(String nombres) {
        this.nombres = nombres;
    }

    /**
     * Obtiene la edad del estudiante.
     * @return edad
     */
    public int getEdad() {
        return edad;
    }

    /**
     * Establece la edad del estudiante.
     * @param edad
     */
    public void setEdad(int edad) {
        this.edad = edad;
    }
}
