import controller.EstudianteController;
import model.Estudiante;
import java.util.Scanner;

/**
 * Vista: permite al usuario interactuar con la aplicación.
 */
public class Main {
    public static void main(String[] args) {
        EstudianteController controller = new EstudianteController();
        Scanner scanner = new Scanner(System.in);
        int opcion;

        do {
            System.out.println("\\n=== MENÚ ESTUDIANTES ===");
            System.out.println("1. Crear estudiante");
            System.out.println("2. Listar estudiantes");
            System.out.println("3. Actualizar estudiante");
            System.out.println("4. Eliminar estudiante");
            System.out.println("5. Salir");
            System.out.print("Seleccione una opción: ");
            opcion = scanner.nextInt();
            scanner.nextLine(); // consumir el salto de línea

            switch (opcion) {
                case 1:
                    System.out.print("ID: ");
                    int id = scanner.nextInt();
                    scanner.nextLine();
                    System.out.print("Apellidos: ");
                    String apellidos = scanner.nextLine();
                    System.out.print("Nombres: ");
                    String nombres = scanner.nextLine();
                    System.out.print("Edad: ");
                    int edad = scanner.nextInt();
                    controller.crearEstudiante(id, apellidos, nombres, edad);
                    System.out.println("Estudiante agregado correctamente.");
                    break;

                case 2:
                    System.out.println("=== LISTADO DE ESTUDIANTES ===");
                    for (Estudiante e : controller.obtenerEstudiantes()) {
                        System.out.printf("ID: %d | %s %s | Edad: %d%n",
                                e.getId(), e.getApellidos(), e.getNombres(), e.getEdad());
                    }
                    break;

                case 3:
                    System.out.print("ID del estudiante a actualizar: ");
                    int idActualizar = scanner.nextInt();
                    scanner.nextLine();
                    System.out.print("Nuevos apellidos: ");
                    String nuevosApellidos = scanner.nextLine();
                    System.out.print("Nuevos nombres: ");
                    String nuevosNombres = scanner.nextLine();
                    System.out.print("Nueva edad: ");
                    int nuevaEdad = scanner.nextInt();
                    boolean actualizado = controller.actualizarEstudiante(idActualizar, nuevosApellidos, nuevosNombres, nuevaEdad);
                    if (actualizado) {
                        System.out.println("Estudiante actualizado correctamente.");
                    } else {
                        System.out.println("Estudiante no encontrado.");
                    }
                    break;

                case 4:
                    System.out.print("ID del estudiante a eliminar: ");
                    int idEliminar = scanner.nextInt();
                    boolean eliminado = controller.eliminarEstudiante(idEliminar);
                    if (eliminado) {
                        System.out.println("Estudiante eliminado correctamente.");
                    } else {
                        System.out.println("Estudiante no encontrado.");
                    }
                    break;

                case 5:
                    System.out.println("Saliendo del programa...");
                    break;

                default:
                    System.out.println("Opción inválida. Intente nuevamente.");
            }

        } while (opcion != 5);

        scanner.close();
    }
}
